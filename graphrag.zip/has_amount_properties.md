## Property Keys for Nodes and Relationships in HAS_AMOUNT

### Node Label: GroupCompany
- name

### Node Label: InventoryLevel4
- name

### Relationship Type: HAS_AMOUNT
- amount
- year
