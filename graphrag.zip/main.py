from langchain.graphs import Neo4jGraph
from langchain_openai import AzureChatOpenAI
from dotenv import load_dotenv
import os
from langchain.prompts import PromptTemplate
from langchain.chains import GraphCypherQAChain
from prompts import NORMALIZE_PROMPT, CYPHER_GENERATION_TEMPLATE
import re
from pydantic import BaseModel, ValidationError
from typing import Optional

load_dotenv()

neo4j_uri = os.getenv("NEO4J_URI")
neo4j_username = os.getenv("NEO4J_USER")
neo4j_password = os.getenv("NEO4J_PASSWORD")

openai_api_key = os.getenv("AZURE_OPENAI_API_KEY")
openai_api_base = os.getenv("AZURE_OPENAI_ENDPOINT")
openai_api_version = os.getenv("AZURE_OPENAI_VERSION")
deployment_name = os.getenv("AZURE_DEPLOYMENT")

print(openai_api_key)
print(openai_api_base)
print(openai_api_version)
print(deployment_name)

graph = Neo4jGraph(
    url=neo4j_uri,
    username=neo4j_username,
    password=neo4j_password,
)



llm = AzureChatOpenAI(
    azure_endpoint=openai_api_base,
    openai_api_version=openai_api_version,
    azure_deployment=deployment_name,
    temperature=0,
    max_tokens=None,
)


class NormalizationResult(BaseModel):
    company_name: Optional[str]
    inventory_type: Optional[str]
    year: Optional[str]
    canonicalized_query: Optional[str]

def normalize_entities(user_query):
    prompt = NORMALIZE_PROMPT.format(user_query=user_query)
    result = llm.invoke(prompt)
    content = result.content if hasattr(result, 'content') else str(result)
    print("Raw LLM output:", content)
    # Extract JSON robustly
    match = re.search(r"\{.*\}", content, re.DOTALL)
    json_str = match.group(0) if match else "{}"
    try:
        normalized = NormalizationResult.model_validate_json(json_str)
    except ValidationError as ve:
        print("Validation error:", ve)
        # Optionally, try to coerce to dict
        normalized = None
    return normalized



cypher_prompt = PromptTemplate(
    input_variables=["query"],
    template=CYPHER_GENERATION_TEMPLATE,
)



# Create the GraphCypherQAChain with the prompt template and graph
chain = GraphCypherQAChain.from_llm(
    graph=graph,
    cypher_llm=llm,
    qa_llm=llm,
    cypher_prompt=cypher_prompt,
    verbose=True,
    allow_dangerous_requests=True,
)

## Chain without the prompt template
# chain2 = GraphCypherQAChain.from_llm(
#     llm, graph=graph, verbose=True, allow_dangerous_requests=True
# )


## TESTING 

user_query = "which group company have lowest finished products produced count in 2023?"
normalized = normalize_entities(user_query)
print('INPUT QUERY NORMALIZED')
print(normalized.canonicalized_query)

query = normalized.canonicalized_query

# Run the chain with added context
result = chain.run({
    "query": query,
})

print('FINAL RESULT')
print(result)
