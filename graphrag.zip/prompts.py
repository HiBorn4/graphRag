NORMALIZE_PROMPT = """
You are a strict information extraction agent.
Your task is to extract and map relevant keywords and phrases from the user query to their exact forms as found in the provided lists.
There are three main entities to extract: Group Company Name, Inventory Type, and Year.
Always match the entire phrase for Inventory Type and Group Company as they appear in the list, even if the user query uses synonyms, partial phrases, or the words are out of order.
If multiple words in the user query best match a multi-word inventory type (for example, "products finished" or "produced products"), always map to the correct complete inventory type from the list ("Finished products produced").
If there are no direct mentions, return null for that field.
**When constructing the "canonicalized_query", replace every occurrence of a canonical entity (company, inventory type, or year) with the same text surrounded by single inverted commas (e.g., 'Finished products produced').**
Return only the JSON object below, and nothing else.

Group company names:
- 001-AS
- 133-FES
- 008-SWARAJ
- 002-HO
- Powerol
- CE
- Agri
- 004-MDS
- Synergy
- 007-SBU
- TW
- 134-TPDS
- 135-INTNL OPER
- 138-CONT SOUR
- 140-NON MRV
- 141-SOURCING
- 139-CORP

Inventory type names:
- Raw Material
- Raw Material in Transit
- Work-in-progress
- Finished products produced
- Stock-in-trade
- Stock-in-trade in transit
- Manufactured components
- Stores and Spares
- Tools

Year values:
- FY23
- FY24

Example:
User query: which group company have lowest Finished products produced count in 2023?
Returned JSON:
{{
  "company_name": null,
  "inventory_type": "Finished products produced",
  "year": "FY23",
  "canonicalized_query": "which group company have lowest 'Finished products produced' count in 'FY23'?"
}}

User query:
{user_query}

Return only this JSON object (use null if not found):
{{
  "company_name": "<matching group company name>",
  "inventory_type": "<matching inventory type>",
  "year": "<matching year>",
  "canonicalized_query": "<original query with all keywords replaced by their canonical KG forms, and all canonical entities surrounded by single inverted commas>"
}}
"""







CYPHER_GENERATION_TEMPLATE = """
Task: Generate a Cypher query to answer the user's question based on the provided graph schema.
Instructions:
- Use only the node labels, relationship types, and properties described in the schema.
- Do not use any other relationship types or properties that are not provided.
- Define all variables before use; do not reference undefined variables.
- Always bind relationship variables in the MATCH clause before referencing them.
- Use meaningful variable names and consistent aliases throughout the query.
- When aggregating or comparing, include the names of group companies and inventory types in the RETURN clause when relevant.
- Only use group company names and inventory type names from the provided lists.
- When aggregating data by different property values (like year), use a single MATCH with a relationship variable, and aggregate using CASE WHEN on that property.
- If the user question specifies a company, inventory type, and year, the Cypher query MUST filter for all three using property matching in the MATCH clause.
- Do not include explanations, comments, or apologies.
- Return only the Cypher query.

Schema of the Knowledge Graph
('Node properties:\n'
 'GroupCompany 'name: STRING'\n'
 'InventoryType 'name: STRING'\n'
 'Inventories 'name: STRING'\n'
 'Relationship properties:\n'
 'HAS_INVENTORY 'year: STRING, amount: FLOAT'\n'
 'The relationships:\n'
 '(:GroupCompany)-[:HAS_INVENTORY]->(:InventoryType)\n'
 '(:InventoryType)-[:type_of_inventories]->(:Inventories)')

Examples:
# Question: How many inventory types does GroupCompany 'group-company-name' have?
MATCH (g:GroupCompany {{name: 'group-company-name'}})-[:HAS_INVENTORY]->(i:InventoryType)
RETURN g.name AS company_name, count(DISTINCT i) AS inventoryTypeCount

# Question: What is the total amount of inventory for GroupCompany 'group-company-name' in year 'year-value'?
MATCH (g:GroupCompany {{name: 'group-company-name'}})-[h:HAS_INVENTORY {{year: 'year-value'}}]->(i:InventoryType)
RETURN g.name AS company_name, sum(h.amount) AS totalAmount

# Question: What is the total amount of 'inventory-type-name' for GroupCompany 'group-company-name' in year 'year-value'?
MATCH (g:GroupCompany {{name: 'group-company-name'}})-[h:HAS_INVENTORY {{year: 'year-value'}}]->(i:InventoryType {{name: 'inventory-type-name'}})
RETURN sum(h.amount) AS totalAmount

# Question: Show the amount of each inventory type for each company in year 'year-value'.
MATCH (g:GroupCompany)-[h:HAS_INVENTORY {{year: 'year-value'}}]->(i:InventoryType)
RETURN g.name AS company_name, i.name AS inventory_type, h.amount AS amount
ORDER BY company_name, inventory_type

# Question: Which inventory type has the highest difference in count for FY23 and FY24 across all companies?
MATCH (g:GroupCompany)-[h:HAS_INVENTORY]->(i:InventoryType)
WHERE h.year IN ['FY24', 'FY23']
WITH i.name AS inventory_type,
     sum(CASE WHEN h.year = 'FY24' THEN h.amount ELSE 0 END) AS fy24_total,
     sum(CASE WHEN h.year = 'FY23' THEN h.amount ELSE 0 END) AS fy23_total
RETURN
  inventory_type,
  fy24_total,
  fy23_total,
  (fy24_total - fy23_total) AS difference
ORDER BY abs(difference) DESC
LIMIT 1

The question is:
{question}
"""